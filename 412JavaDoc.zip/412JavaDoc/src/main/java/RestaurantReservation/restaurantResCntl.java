/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package RestaurantReservation;
import java.awt.event.ActionEvent;
/**
 *
 * @author noellefajt
 */
public class restaurantResCntl {
    
    /**
     * constructor for setting up the restaurant reservation controller
     */
    public restaurantResCntl(){
        
    }
    
    /**
     * method that creates the reservation restaurant UI
     */
    public void createRestaurantResUI(){
        
    } 
    
    /**
     * method that will handle all the event actions on the restaurant res UI,
     * depending on the action this method will change the interface accordingly
     * @param e = event click 
     */
    public void actionPerformed(ActionEvent e) {
    }
}